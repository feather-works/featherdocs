#!/bin/sh
# Instala o FeatherDocs só para este usuário (~/.local), sem administrador.
set -e
cd "$(dirname "$0")"
mkdir -p ~/.local/bin ~/.local/share/applications ~/.local/share/mime/packages
install -m755 featherdocs ~/.local/bin/featherdocs
sed "s#^Exec=featherdocs#Exec=$HOME/.local/bin/featherdocs#" featherdocs.desktop > ~/.local/share/applications/featherdocs.desktop
cp featherdocs-mime.xml ~/.local/share/mime/packages/featherdocs.xml
for t in 16 24 32 48 64 128 256 512; do
  mkdir -p ~/.local/share/icons/hicolor/${t}x${t}/apps
  cp icones/featherdocs-$t.png ~/.local/share/icons/hicolor/${t}x${t}/apps/featherdocs.png
done
update-mime-database ~/.local/share/mime 2>/dev/null || true
update-desktop-database ~/.local/share/applications 2>/dev/null || true
echo "FeatherDocs instalado. Procure por \"FeatherDocs\" no menu de aplicativos."
